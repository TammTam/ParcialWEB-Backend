package com.juanreyes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.juanreyes.model.libro;

@Repository
public interface LibroRepository extends JpaRepository<libro, Long> {
}