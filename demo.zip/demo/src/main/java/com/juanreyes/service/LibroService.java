package com.juanreyes.service;

import com.juanreyes.model.libro;
import com.juanreyes.repository.LibroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LibroService {

    private final LibroRepository libroRepository;

    @Autowired
    public LibroService(LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }

    public List<libro> obtenerTodosLosLibros() {
        return libroRepository.findAll();
    }

    public libro crearLibro(libro libro) {
        return libroRepository.save(libro);
    }

    public libro obtenerLibroPorId(Long id) {
        return libroRepository.findById(id).orElse(null);
    }

    public libro actualizarLibro(Long id, libro libro) {
        libro libroExistente = obtenerLibroPorId(id);
        if (libroExistente != null) {
            libroExistente.setTitulo(libro.getTitulo());
            libroExistente.setReferencia(libro.getReferencia());
            libroExistente.setAutor(libro.getAutor());
            libroExistente.setPrecio(libro.getPrecio());
            libroExistente.setUbicacion(libro.getUbicacion());
            return libroRepository.save(libroExistente);
        } else {
            return null;
        }
    }

    public boolean eliminarLibro(Long id) {
        libro libroExistente = obtenerLibroPorId(id);
        if (libroExistente != null) {
            libroRepository.delete(libroExistente);
            return true;
        } else {
            return false;
        }
    }
}